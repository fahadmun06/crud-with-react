import dayjs from "dayjs"

window.dateFormat = date => dayjs(date).format("DD-MM-YYYY")