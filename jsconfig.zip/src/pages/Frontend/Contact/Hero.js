import React from 'react'

export default function Contact() {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col">
            <h1 className="text-center">Contact</h1>
          </div>
        </div>
      </div>
    </>
  )
}
