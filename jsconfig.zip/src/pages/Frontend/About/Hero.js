import React from 'react'

export default function About() {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col">
            <h1 className="text-center">About</h1>
          </div>
        </div>
      </div>
    </>
  )
}
